package com.springboot.service;


import java.util.List;

import com.springboot.entity.FrontendTransaction;
import com.springboot.entity.Transactions;

public interface TransactionsService {

	public List<Transactions> getAllPendingTransactions();
	public String addTransaction(Transactions transactions);
	public String updateTransaction(int id);
	public List<FrontendTransaction> getTransactionsForAccountNumber(String accountNumber);
	public List<FrontendTransaction> getFilteredTransactions(String accountNumber, String startDate, String endDate);
	
}
