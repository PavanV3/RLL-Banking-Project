export interface ChequeBooks {
    chequeBookNumber: string,
    accountNumber: string,
    accountType: string,
    chequeBookIssueDate: Date,
    chequeBookStatus: number
}
