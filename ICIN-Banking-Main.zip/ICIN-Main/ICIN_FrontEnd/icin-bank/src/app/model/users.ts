export interface Users {
    accountNumber: string,
    accountHolderName: string,
    accountLoginUserId: string,
    accountLoginPassword: string,
    accountIsBlocked: number
}
