import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-register',
  templateUrl: './new-register.component.html',
  styleUrls: ['./new-register.component.css']
})
export class NewRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    
  }

}
